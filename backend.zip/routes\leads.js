const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const nodemailer = require('nodemailer');

// POST /api/leads - Submit B2B RFP Inquiry
router.post('/', [
  body('name').trim().notEmpty().withMessage('Contact Person name is required.'),
  body('email').trim().isEmail().withMessage('A valid Work Email ID is required.'),
  body('phone').optional().trim().isLength({ min: 10, max: 15 }).withMessage('Phone number must be between 10 and 15 digits.'),
  body('company').optional().trim().escape(),
  body('solutionSector').trim().notEmpty().withMessage('Required Solution Sector dropdown is required.'),
  body('details').optional().trim().escape(),
  body('sessionId').optional().trim()
], async (req, res, next) => {
  try {
    const prisma = req.prisma;
    
    // Check validation results
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ error: 'Validation Failed', details: errors.array() });
    }

    const { name, email, phone, company, solutionSector, details, sessionId } = req.body;

    // 1. Create Lead in PostgreSQL DB
    const lead = await prisma.lead.create({
      data: {
        name,
        email,
        phone: phone || null,
        company: company || null,
        solutionSector,
        details: details || null,
        sessionId: sessionId || null
      }
    });

    // 2. Dispatch Automatic Email Notification
    const mailHost = process.env.SMTP_HOST;
    const mailPort = parseInt(process.env.SMTP_PORT) || 2525;
    const mailUser = process.env.SMTP_USER;
    const mailPass = process.env.SMTP_PASS;
    const mailFrom = process.env.SMTP_FROM || 'no-reply@genexlogistics.in';
    const alertRecipient = process.env.ALERT_EMAIL_RECIPIENT || 'solutions@genexlogistics.in';

    // Construct detailed corporate lead email HTML layout
    const emailHtml = `
      <div style="font-family: Arial, sans-serif; line-height: 1.6; color: #0b132b; max-width: 600px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.05);">
        <div style="background: linear-gradient(135deg, #0b132b 0%, #1c2541 100%); padding: 30px; text-align: center; color: #ffffff;">
          <h2 style="margin: 0; font-size: 24px; letter-spacing: -0.5px;">New B2B RFP Inquiry Received</h2>
          <p style="margin: 5px 0 0 0; color: #06b6d4; font-weight: bold;">Genex Logistics Solutions Desk</p>
        </div>
        <div style="padding: 30px; background-color: #ffffff;">
          <table style="width: 100%; border-collapse: collapse; margin-bottom: 25px;">
            <tr>
              <td style="padding: 10px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold; width: 180px;">Contact Person:</td>
              <td style="padding: 10px 0; border-bottom: 1px solid #f1f5f9; color: #475569;">${name}</td>
            </tr>
            <tr>
              <td style="padding: 10px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold;">Work Email ID:</td>
              <td style="padding: 10px 0; border-bottom: 1px solid #f1f5f9; color: #06b6d4;"><a href="mailto:${email}">${email}</a></td>
            </tr>
            <tr>
              <td style="padding: 10px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold;">Mobile Phone:</td>
              <td style="padding: 10px 0; border-bottom: 1px solid #f1f5f9; color: #475569;">${phone || 'Not provided'}</td>
            </tr>
            <tr>
              <td style="padding: 10px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold;">Company Name:</td>
              <td style="padding: 10px 0; border-bottom: 1px solid #f1f5f9; color: #475569;">${company || 'Not provided'}</td>
            </tr>
            <tr>
              <td style="padding: 10px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold;">Solution Sector:</td>
              <td style="padding: 10px 0; border-bottom: 1px solid #f1f5f9; color: #10b981; font-weight: bold;">${solutionSector}</td>
            </tr>
          </table>
          
          <div style="background-color: #f8fafc; border-radius: 8px; padding: 20px; border: 1px solid #e2e8f0; margin-bottom: 20px;">
            <h4 style="margin: 0 0 10px 0; color: #0b132b; font-size: 14px;">Requirement Details:</h4>
            <p style="margin: 0; color: #475569; white-space: pre-wrap; font-size: 14px;">${details || 'No details provided.'}</p>
          </div>
          
          <div style="font-size: 12px; color: #94a3b8; text-align: center; border-top: 1px solid #f1f5f9; padding-top: 20px;">
            This email was automatically dispatched from the Genex B2B website pipeline.<br>
            Session ID: <code style="background-color: #f1f5f9; padding: 2px 4px; border-radius: 4px;">${sessionId || 'N/A'}</code>
          </div>
        </div>
      </div>
    `;

    // Initialize Mailer if credentials exist
    try {
      const transporter = nodemailer.createTransport({
        host: mailHost,
        port: mailPort,
        auth: {
          user: mailUser,
          pass: mailPass
        }
      });

      await transporter.sendMail({
        from: `Genex Leads Hub <${mailFrom}>`,
        to: alertRecipient,
        subject: `🚨 [New B2B Lead] ${company || name} - ${solutionSector}`,
        html: emailHtml
      });
      console.log(`[Leads Routing] RFP email alert successfully dispatched to ${alertRecipient}`);
    } catch (mailError) {
      // Capture and log mail failure but do not crash lead creation response
      console.warn('[Leads Routing] Warning: Failed to send email notification:', mailError.message);
    }

    return res.status(201).json({
      status: 'success',
      message: 'B2B RFP proposal successfully submitted.',
      leadId: lead.id
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
