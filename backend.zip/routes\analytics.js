const express = require('express');
const router = express.Router();
const parser = require('ua-parser-js');
const geoip = require('geoip-lite');

// Ingest client events (pageviews, clicks, forms, exits, performance timing)
router.post('/event', async (req, res, next) => {
  try {
    const prisma = req.prisma;
    const data = req.body;

    const {
      visitorId,
      sessionId,
      path,
      title,
      referrer,
      screenResolution,
      eventType,
      loadTimeMs,
      ttfbMs,
      cacheStatus,
      target,
      value
    } = data;

    if (!visitorId || !sessionId) {
      return res.status(400).json({ error: 'Missing identity mapping parameters.' });
    }

    // 1. Resolve User entity (find or create)
    await prisma.user.upsert({
      where: { id: visitorId },
      update: {},
      create: { id: visitorId }
    });

    // 2. Extract Device & Network details
    const ua = parser(req.headers['user-agent']);
    const clientIp = req.headers['x-forwarded-for'] || req.socket.remoteAddress || '';
    
    // Resolve clean IP for geoip lookup
    let cleanIp = clientIp.split(',')[0].trim();
    if (cleanIp === '::1' || cleanIp === '127.0.0.1' || cleanIp.startsWith('::ffff:127.')) {
      cleanIp = '8.8.8.8'; // Default to a standard IP for testing geolocation locally
    }

    const geo = geoip.lookup(cleanIp) || {};

    let screenW = null;
    let screenH = null;
    if (screenResolution && screenResolution.includes('x')) {
      const parts = screenResolution.split('x');
      screenW = parseInt(parts[0]);
      screenH = parseInt(parts[1]);
    }

    // 3. Resolve Session entity (find or create)
    let session = await prisma.session.findUnique({
      where: { id: sessionId }
    });

    if (!session) {
      session = await prisma.session.create({
        data: {
          id: sessionId,
          userId: visitorId,
          ipAddress: clientIp,
          userAgent: req.headers['user-agent'],
          deviceType: ua.device.type || 'desktop',
          browserName: ua.browser.name || 'unknown',
          osName: ua.os.name || 'unknown',
          country: geo.country || 'Localhost',
          city: geo.city || 'Localhost',
          screenWidth: screenW,
          screenHeight: screenH
        }
      });
    }

    // 4. Record details by event category
    if (eventType === 'pageview') {
      await prisma.pageView.create({
        data: {
          sessionId,
          path,
          title,
          referrer,
          loadTimeMs: loadTimeMs ? parseInt(loadTimeMs) : null,
          ttfbMs: ttfbMs ? parseInt(ttfbMs) : null
        }
      });
    } else {
      // Record behavioral events (click, idle, focus, exit, form_abandon)
      await prisma.event.create({
        data: {
          sessionId,
          type: eventType,
          target: target || null,
          value: value || null
        }
      });
    }

    return res.status(201).json({ status: 'success', eventId: sessionId });
  } catch (error) {
    next(error);
  }
});

// Calculate retention cohort, DAU/MAU and timings
router.get('/metrics', async (req, res, next) => {
  try {
    const prisma = req.prisma;

    // A. DAU / MAU unique calculations (Today vs past 30 days)
    const todayStart = new Date();
    todayStart.setHours(0,0,0,0);

    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    // Current DAU (Today)
    const activeToday = await prisma.session.findMany({
      where: { createdAt: { gte: todayStart } },
      select: { userId: true },
      distinct: ['userId']
    });
    const dau = activeToday.length;

    // Current MAU (Past 30 days)
    const activeMonth = await prisma.session.findMany({
      where: { createdAt: { gte: thirtyDaysAgo } },
      select: { userId: true },
      distinct: ['userId']
    });
    const mau = activeMonth.length;

    // B. Performance Timing Averages per page route
    const timingsRaw = await prisma.pageView.groupBy({
      by: ['path'],
      _avg: {
        loadTimeMs: true,
        ttfbMs: true
      },
      _count: {
        id: true
      }
    });

    const performanceTimings = timingsRaw.map(item => ({
      path: item.path,
      hitCount: item._count.id,
      avgLoadTimeMs: Math.round(item._avg.loadTimeMs || 0),
      avgTtfbMs: Math.round(item._avg.ttfbMs || 0)
    }));

    // C. Behavioral Drop-off & Exit Pages
    const exits = await prisma.event.groupBy({
      by: ['target'],
      where: { type: 'exit_page' },
      _count: {
        id: true
      }
    });
    
    const dropOffPages = exits.map(item => ({
      path: item.target || '/',
      exitCount: item._count.id
    })).sort((a, b) => b.exitCount - a.exitCount);

    // D. Form Abandonment metrics
    const formStarts = await prisma.event.count({ where: { type: 'form_start' } });
    const formAbandons = await prisma.event.count({ where: { type: 'form_abandon' } });
    const formSubmits = await prisma.event.count({ where: { type: 'form_submit_click' } });

    const formStats = {
      started: formStarts,
      abandoned: formAbandons,
      submitted: formSubmits,
      abandonmentRate: formStarts > 0 ? parseFloat(((formAbandons / formStarts) * 100).toFixed(2)) : 0
    };

    // E. Cohort Retention logic calculation (Day 1 / Day 7)
    // Find when users first visited (cohort boundary)
    const users = await prisma.user.findMany({
      include: {
        sessions: {
          orderBy: { createdAt: 'asc' }
        }
      }
    });

    let cohortSize = 0;
    let day1Retained = 0;
    let day7Retained = 0;

    users.forEach(u => {
      if (u.sessions.length === 0) return;
      
      cohortSize++;
      const joinDate = u.sessions[0].createdAt.getTime();
      
      const oneDayLimit = 24 * 60 * 60 * 1000;
      const sevenDayLimit = 7 * 24 * 60 * 60 * 1000;
      
      let returnedDay1 = false;
      let returnedDay7 = false;

      // Scan subsequent sessions
      for (let i = 1; i < u.sessions.length; i++) {
        const timeDiff = u.sessions[i].createdAt.getTime() - joinDate;
        if (timeDiff >= oneDayLimit && timeDiff < oneDayLimit * 2) {
          returnedDay1 = true;
        }
        if (timeDiff >= sevenDayLimit && timeDiff < sevenDayLimit + oneDayLimit) {
          returnedDay7 = true;
        }
      }

      if (returnedDay1) day1Retained++;
      if (returnedDay7) day7Retained++;
    });

    const retention = {
      cohortSize,
      day1RetentionRate: cohortSize > 0 ? parseFloat(((day1Retained / cohortSize) * 100).toFixed(2)) : 0,
      day7RetentionRate: cohortSize > 0 ? parseFloat(((day7Retained / cohortSize) * 100).toFixed(2)) : 0
    };

    return res.status(200).json({
      dau,
      mau,
      retentionRatio: mau > 0 ? parseFloat((dau / mau).toFixed(4)) : 0,
      performanceTimings,
      dropOffPages,
      formStats,
      retention
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
