const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { PrismaClient } = require('@prisma/client');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Initialize Prisma
const prisma = new PrismaClient();

// Security Headers
app.use(helmet());

// CORS Configuration
app.use(cors({
  origin: '*', // Allow all origins for the tracker, adjust for production domains
  methods: ['GET', 'POST', 'OPTIONS'],
  allowedHeaders: ['Content-Type']
}));

// Body Parsers (Increased limit to support larger analytics payloads)
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Global Rate Limiting
const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 1000, // limit each IP to 1000 requests per windowMs
  message: 'Too many requests from this IP, please try again later.'
});
app.use(globalLimiter);

// Specific limiter for B2B RFP submissions (prevents lead submission spam)
const leadSubmissionLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 15, // limit each IP to 15 RFP submissions per hour
  message: 'RFP submission limit reached. Please contact solutions@genexlogistics.in directly.'
});

// Pass Prisma instance through request
app.use((req, res, next) => {
  req.prisma = prisma;
  next();
});

// Import route files
const analyticsRouter = require('./routes/analytics');
const leadsRouter = require('./routes/leads');

// Register API Routes
app.use('/api/analytics', analyticsRouter);
app.use('/api/leads', leadSubmissionLimiter, leadsRouter);

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'UP', timestamp: new Date().toISOString() });
});

// Global Error Handler
app.use((err, req, res, next) => {
  console.error('Unhandled Error:', err.message);
  res.status(500).json({
    error: 'Internal Server Error',
    message: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

// Start Server
const server = app.listen(PORT, () => {
  console.log(`[Genex Backend] Server running on port ${PORT}`);
});

// Graceful Teardown
const shutdown = async () => {
  console.log('[Genex Backend] Initiating graceful shutdown...');
  server.close(async () => {
    console.log('[Genex Backend] HTTP server closed.');
    await prisma.$disconnect();
    console.log('[Genex Backend] Database connection closed.');
    process.exit(0);
  });
};

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
